# EFI Coding style Check Plugin

This CiBuildPlugin finds the Ecc issues of newly added code in pull request.

## Configuration

The plugin can be configured to ignore certain files and issues.

"EccCheck": {
        "ExceptionList": [],
        "IgnoreFiles": []
    },
    """

OPTIONAL List of file to ignore.
